#!/bin/sh

unset JAVA_TOOL_OPTIONS
java -Xmx64m -jar ./bin/TAQueue.jar "$@"